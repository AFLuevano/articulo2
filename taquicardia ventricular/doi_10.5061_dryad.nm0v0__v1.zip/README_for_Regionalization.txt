Data from: “Automatic Supporting System for Regionalization of Ventricular Tachycardia Exit Site in Implantable Defibrillators”

Sanromán-Junquera, Margarita; Mora-Jiménez, Inmaculada; Almendral, Jesús; García-Alberola, Arcadio; Rojo-Álvarez, José Luis.

IDPatient: patient identifier
NumberOfPacingSite: pacing site number
Half-1: apical vs basal half
Half-2: septal vs lateral half
Half-3: superior vs inferior half
TypeOfTissue: scar or normal tissue: 2 ( > 1.5 mV), 1 (1.5 - 0.5 mV), 0 (< 0.5 mV).
X: X coordinate of the pacing site
Y: Y coordinate of the pacing site
Z: X coordinate of the pacing site
Vp: voltage of peak deflection
Vi: voltage of initial deflection
Vf: voltage of final deflection
tob:  time interval between the onset of far-field electrogram and the bipolar intrinsic deflection
tp:  time instant of Vp
ti:  time instant of Vi
tf: time instant of Vf
Far-fieldEGMWaveformWithStim:  averaged beat waveform far-field electrogram
BipolarEGMWaveform: averaged beat waveform bipolar electrogram.